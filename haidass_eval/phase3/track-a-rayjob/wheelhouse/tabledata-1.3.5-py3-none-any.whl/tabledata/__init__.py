"""
.. codeauthor:: Tsuyoshi Hombashi <tsuyoshi.hombashi@gmail.com>
"""

from .__version__ import __author__, __copyright__, __email__, __license__, __version__
from ._common import convert_idx_to_alphabet
from ._constant import PatternMatch
from ._converter import to_value_matrix
from ._core import TableData
from ._logger import set_logger
from .error import DataError, InvalidHeaderNameError, InvalidTableNameError, NameValidationError


__all__ = (
    "__author__",
    "__copyright__",
    "__email__",
    "__license__",
    "__version__",
    "convert_idx_to_alphabet",
    "set_logger",
    "to_value_matrix",
    "PatternMatch",
    "TableData",
    "DataError",
    "InvalidHeaderNameError",
    "InvalidTableNameError",
    "NameValidationError",
)
